'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/


const Route = use('Route')

Route.on('/').render('home').as('home').middleware(['auth'])

Route.get('register', 'Auth/RegisterController.showRegisterForm').middleware (['authenticated'])
Route.post('register', 'Auth/RegisterController.register').as('register')
Route.get('register/confirm/:token', 'Auth/RegisterController.confirmEmail' )
Route.get('login', 'Auth/LoginController.showLoginForm').middleware(['authenticated'])
Route.post('login', 'Auth/LoginController.login').as('login')
Route.get('logout', 'Auth/AuthenticatedController.logout')
Route.get('password/reset', 'Auth/PasswordResetController.showLinkRequestForm')
Route.post('password/email', 'Auth/PasswordResetController.sendResetLinkEmail')
Route.get('password/reset/:token', 'Auth/PasswordResetController.showResetForm')
Route.post('password/reset', 'Auth/PasswordResetController.reset')



// Route.get('/request', 'InventoryMController.index')
// Route.get('request', 'InventoryMController.index')
// Route.get('request/new', 'InventoryMController.add_form')
// Route.get('request/edit/:id', 'InventoryMController.edit_form')
// Route.get('request/:id', 'InventoryMController.show')
// Route.post('request/new', 'InventoryMController.store')
// Route.patch('request/edit/:id', 'InventoryMController.update')
// Route.delete('request/:id', 'InventoryMController.destroy')


//Route.get('inventoryfolder', 'InventoryMController.inventoryhome')
//Route.get('inventoryfolder/supplierdetail', 'InventoryMController.supplier')
// Route.get('inventoryfolder/index', 'InventoryMController.index')
// Route.get('inventoryfolder/edit/:id', 'InventoryMController.edit_form')
// Route.get('inventoryfolder/:id', 'InventoryMController.show')
// Route.post('inventoryfolder/new', 'InventoryMController.store')
// Route.patch('inventoryfolder/edit/:id', 'InventoryMController.update')
// Route.delete('inventoryfolder/:id', 'InventoryMController.destroy')


Route.get('inventoryfolder', 'HomeController.inventoryhome')
Route.get('inventoryfolder/detail', 'PeripheralController.peripheralsdetail')
Route.get('inventoryfolder/supplierdetail', 'SupplierController.supplier')
Route.get('inventoryfolder/new', 'WorkstationController.add_workstation')














// Get view from Browser
// Post receives from form submit
// Put receives from form submit
// Patch receives from form submit
// Delete view from Browser GET _method=delete

// Route.get('/', 'TaskController.index')
// Route.post('tasks', 'TaskController.store')
// Route.delete('tasks/:id', 'TaskController.destroy')

