'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class PeripheralSchema extends Schema {
  up () {
    this.create('peripherals', (table) => {
      table.increments()
      table.string('brand_model')
      table.string('serial_no')
      table.text('specification')
      table.string('color')
      table.datetime('date_purchase')
      table.integer('supplier_id').unsigned().references('id').on('suppliers')
      table.integer('added_by').unsigned().references('id').on('users')
      table.datetime('added_on')
      table.timestamps()
    })
  }

  down () {
    this.table(table => {
      table.dropForeign('supplier_id')
      table.dropForeign('added_by')
    })
    this.drop('peripherals')
  }
}

module.exports = PeripheralSchema
