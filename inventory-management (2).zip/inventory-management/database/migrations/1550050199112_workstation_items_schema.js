'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WorkstationItemSchema extends Schema {
  up () {
    this.create('workstation_items', (table) => {
      table.increments()
      // table.primary('ws_item_id')
      table.integer('item_id').unsigned().references('id').on('peripherals')
      table.integer('ws_id').unsigned().references('id').on('workstations')
      table.timestamps()
    })
  }

  down () {
    this.table(table => {
      table.dropForeign('ws_id')
      table.dropForeign('item_id')
    })
    this.drop('workstation_items')
  }
}

module.exports = WorkstationItemSchema
