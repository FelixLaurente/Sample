'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class SupplierSchema extends Schema {
  up () {
    this.create('suppliers', (table) => {
      table.increments()
      table.string('name')
      table.string('location')
      table.integer('added_by').unsigned().references('id').on('users')
      table.datetime('added_on')
      table.timestamps()

    })
  }

  down () {
    this.table(table => {
      table.dropForeign('added_by')
    })
    this.drop('suppliers')
  }
}

module.exports = SupplierSchema
