'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class WorkstationItem extends Model {
    peripheral(){
        return this.hasOne('App/Models/Peripheral')
    }
}

module.exports = WorkstationItem
