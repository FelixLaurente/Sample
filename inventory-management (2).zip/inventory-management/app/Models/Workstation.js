'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Workstation extends Model {
    items(){
        return this.hasMany('App/Models/WorkstationItem')
    }

    peripherals(){
        return this.manyThrough('App/Models/WorkstationItem', 'peripheral')
    }
}

module.exports = Workstation
