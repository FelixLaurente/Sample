'use strict'

class HomeController {

    async inventoryhome({ view }) {
        
        return view.render('inventoryfolder.inventoryhome')
        
    }
}

module.exports = HomeController
