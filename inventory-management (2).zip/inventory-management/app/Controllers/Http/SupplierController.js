'use strict'

class SupplierController {

    async supplier({ view }) {
        
        return view.render('inventoryfolder.supplier')
        
    }
}

module.exports = SupplierController
