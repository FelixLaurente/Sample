'use strict'
const RequestHdr = use('App/Models/RequestHdr')
const RequestDtl = use('App/Models/RequestDtl')



const validator = use( 'Validator' )

// remember to reference the Task model at the top
class InventoryController {
    async index({ view }) {
        const rqsHdrs = await RequestHdr.all()

        return view.render('request.index', { rqsHdrs: rqsHdrs.toJSON() })
    
    }

    async login_form ( { view }) {
         return view.render('request.login_form')
     }

    async add_form ({ view }) {
        return view.render('request.add_workstation')
    }

    async edit_form ({ view, params }) {
        const rqsHdr = await RequestHdr
            .query()
            .where('request_id', params.id)
            .with('dtls')
            .first();

        // return rqsHdr;
        return view.render('request.add_workstation', { rqsHdr : rqsHdr.toJSON() })
    }

   

    async store({ request, response, session }) {
        const dataHdr       = new RequestHdr;
      
        var data            = request.post();
        var supplier        = data.supplier;
        var supplier_id     = data.supplier_id;
        var name            = data.name;
        var location        = data.location
        var added_by        = data.added_by;
        var added_on        = data.added_on;
        var peripherals     = data.peripherals;
        var item_id         = data.item_id;
        var brand_model     = data.brand_model;
        var serial_no       = data.serial_no;
    
        dataHdr.supplier            = supplier;
        dataHdr.supplier_id         = supplier_id;
        dataHdr.name                = name;
        dataHdr.location            = location;
        dataHdr.added_by            = added_by;
        dataHdr.added_on            = added_on;
        
       
      

        await dataHdr.save();

        var requestID = dataHdr.request_id;

        for(var i in peripherals) {
            if(peripherals[i] == '')
                continue;

            const dataDtl     = new RequestDtl;
           
            
            dataDtl.request_hdr_id     = requestID;
            dataDtl.peripherals        = peripherals[i];
            dataDtl.item_id            = item_id[i];
            dataDtl.brand_model        = brand_model[i];
            dataDtl.serial_no	       = serial_no[i];
          
            await dataDtl.save();
           
        }

        response.redirect('/')
    }

    async update({ request, response, params }) {
        var data                     = request.post();
        var peripherals              = data.peripherals;
        var item_id                  = data.item_id;
        var brand_model              = data.brand_model;
        var serial_no                = data.serial_no;

        const rqsHdr                    = await RequestHdr.find(params.id)
        rqsHdr.supplier                 = request.input('supplier')
        rqsHdr.supplier_id              = request.input('supplier_id')
        rqsHdr.name                     = request.input('name')
        rqsHdr.location                 = request.input('location')
        rqsHdr.added_by                 = request.input('added_by')
        rqsHdr.added_on                 = request.input('added_on')

        await rqsHdr.save()
        
        await RequestDtl.query().where('request_hdr_id', params.id).delete();
        
        
        for(var i in peripherals) {
            if(peripherals[i] == '')
                continue;

            const dataDtl      = new RequestDtl;
            
            
            dataDtl.request_hdr_id       = params.id;
            dataDtl.peripherals          = peripherals[i];
            dataDtl.item_id              = item_id[i];
            dataDtl.brand_model          = brand_model[i];
            dataDtl.serial_no	         = serial_no[i];
        
            await dataDtl.save();
            
        }

        response.redirect('/')
    }

    async destroy({ params, session, response }) {
        await RequestDtl.query().where("request_hdr_id", params.id).delete();
        const rqsHdr    = await RequestHdr.find(params.id);
        await rqsHdr.delete();

        // Fash success message to session
        session.flash({ notification: 'Inventory deleted!' })

        return response.redirect('back')

        }
    }
        


module.exports = InventoryController


