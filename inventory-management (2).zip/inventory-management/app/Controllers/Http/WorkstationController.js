'use strict'

class WorkstationController {


    async add_workstation ({ view }) {
        return view.render('inventoryfolder.add_workstation')
     }
}

module.exports = WorkstationController
