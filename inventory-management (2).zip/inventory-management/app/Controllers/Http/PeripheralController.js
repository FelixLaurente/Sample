'use strict'



class PeripheralController {


    async peripheralsdetail ({ view }) {
        return view.render('inventoryfolder.peripheralsdetail')
     }
}


module.exports = PeripheralController
