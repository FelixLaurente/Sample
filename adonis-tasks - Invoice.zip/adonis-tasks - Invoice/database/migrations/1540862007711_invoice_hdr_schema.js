'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class InvoiceHdrSchema extends Schema {
  up () {
    this.create('invoice_hdrs', (table) => {
      table.increments()
      table.string('invoice_no')
      table.date('invoice_date')
      table.string('customer')
      table.timestamps()
    })
  }

  down () {
    this.drop('invoice_hdrs')
  }
}

module.exports = InvoiceHdrSchema
