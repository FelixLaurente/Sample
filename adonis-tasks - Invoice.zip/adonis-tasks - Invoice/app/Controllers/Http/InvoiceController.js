'use strict'
const InvoiceHdr = use('App/Models/InvoiceHdr')

const validator = use( 'Validator' )

// remember to reference the Task model at the top
class InvoiceController {
    async index({ view }) {
        const invHdrs = await InvoiceHdr.all()
        return view.render('invoice.index', { invHdrs: invHdrs.toJSON() })
    }

    async add_form ({ view }) {
        return view.render('invoice.add_form')
    }

    async edit_form ({ view, params }) {
        const invHdr = await InvoiceHdr.find(params.id)
        return view.render('invoice.add_form', { invHdr : invHdr.toJSON() })
    }

   

    async store({ request, response, session }) {
        const validation = await validator.validateAll(request.post(), {
            invoice_no  : 'required',
            invoice_date: 'required',
            customer    : 'required'
        })

        if(validation.fails()) {
            session
                .withErrors(validation.messages())
                .flashAll()

            return response.redirect('back')
        }
        
        // persist to database
        const invHdr        = new InvoiceHdr()
        invHdr.invoice_no   = request.input('invoice_no')
        invHdr.invoice_date = request.input('invoice_date')
        invHdr.customer     = request.input('customer')
        
        await invHdr.save()

        response.redirect('/')
    }

    async update({ request, response, params }) {
        const invHdr        = await InvoiceHdr.find(params.id)
        invHdr.invoice_no   = request.input('invoice_no')
        invHdr.invoice_date = request.input('invoice_date')
        invHdr.customer     = request.input('customer')
        
        await invHdr.save()

        response.redirect('/')
    }

    async destroy({ params, session, response }) {

        const invHdr = await InvoiceHdr.find(params.id)
        await invHdr.delete()

        // Fash success message to session
        session.flash({ notification: 'Invoice deleted!' })

        return response.redirect('back')

        }
    }
        


module.exports = InvoiceController


