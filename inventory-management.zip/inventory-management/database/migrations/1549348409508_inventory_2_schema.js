'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class Inventory2Schema extends Schema {
  up () {
    this.create('inventory_2_s', (table) => {
      table.increments()
      table.string('ws_item')
      table.string('ws_item_id')
      table.string('item_id')
      table.string('ws_id')
      table.timestamps()
    })
  }

  down () {
    this.drop('inventory_2_s')
  }
}

module.exports = Inventory2Schema
