'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WorkstationSchema extends Schema {
  up () {
    this.create('workstations', (table) => {
      table.increments()
      table.string('ws_id')
      table.string('ws_name')
      table.string('ws_status')
      table.string('ws_user')
      table.timestamps()
    })
  }

  down () {
    this.drop('workstations')
  }
}

module.exports = WorkstationSchema
