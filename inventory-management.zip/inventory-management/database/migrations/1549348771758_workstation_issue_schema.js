'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WorkstationIssueSchema extends Schema {
  up () {
    this.create('workstation_issues', (table) => {
      table.increments()
      table.string('issue_id')
      table.string('ws_id')
      table.string('issue')
      table.string('fixes')
      table.string('fixed_by')
      table.string('fixed_on')
      table.string('added_by')
      table.string('added_on')
      table.timestamps()
    })
  }

  down () {
    this.drop('workstation_issues')
  }
}

module.exports = WorkstationIssueSchema
