'use strict'

class EmpWorkstationController {

        async emp_workstation({ view }) {
            
            return view.render()
        }
    }


module.exports = EmpWorkstationController