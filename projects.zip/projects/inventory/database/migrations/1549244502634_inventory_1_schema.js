'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class Inventory1Schema extends Schema {
  up () {
    this.create('inventory_1_s', (table) => {
      table.increments()
      table.string('peripherals')
      table.string('item_id')
      table.string('brand_model')
      table.string('serial_no')
      table.string('specifications')
      table.string('color')
      table.string('date_purchase')
      table.string('added_by')
      table.string('added_on')
      table.timestamps()
    })
  }

  down () {
    this.drop('inventory_1_s')
  }
}

module.exports = Inventory1Schema
