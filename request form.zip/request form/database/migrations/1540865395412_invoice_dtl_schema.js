'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class InvoiceDtlSchema extends Schema {
  up () {
    this.create('invoice_dtls', (table) => {
      table.increments()
      table.integer('invoice_hdr_id').unsigned().references('id').inTable('invoice_hdrs')
      table.string('particular')
      table.float('qty')
      table.float('price')
      table.timestamps()
    })
  }

  down () {
    this.drop('invoice_dtls')
  }
}

module.exports = InvoiceDtlSchema
