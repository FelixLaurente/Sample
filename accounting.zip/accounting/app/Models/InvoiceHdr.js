'use strict'


const Model = use('Model')
const moment = use('moment')

class InvoiceHdr extends Model {
  getInvoiceDate (invoiceDate) {
    return moment(invoiceDate).format('MMMM Do YYYY')
  }
}



module.exports = InvoiceHdr
