'use strict'

//Bring in model
const Post = use('App/Models/Post')

// Bringing in validator

 const { validate } = use( 'Validator')

class PostController {
    async index ({ view }) {
        // const posts = [
        //     {title: 'Post One', body: 'This is post one'},
        //     {title: 'Post Two', body: 'This is post two'},
        //     {title: 'Post Three', body: 'This is post three'}
        // ]

        const posts = await Post.all()

        return view.render('posts.index', {
            particular      :'Latest Inventory',
            qty             :'Latest Inventory',
            price           :'Latest Inventory',
            total           :'Latest Inventory',
            posts: posts.toJSON() // calling the Latest inventory
        })
    }
   
    async details({ params, view }) {
        const post = await Post.find(params.id)

        return view.render('posts.details', {
            post: post
        })
    }

    async add({ view }){
        return view.render('posts.add')

    }

    async store({ request, response, session }) {
        // Validate input
        const validation = await validate(request.all(), {
            particular: 'required|min:0|max:255',
            qty:        'required|min:0|max:255',
            price:      'required|min:0|max:255',
            total:      'required|min:0'

        })

        if(validation.fails()){
            session.withErrors(validation.messages()).flashAll()
            return response.redirect('back')
        }

        const post = new Post();

        post.particular     = request.input('particular')
        post.qty            = request.input('qty')
        post.price          = request.input('price')
        post.total          = request.input('total')

        await post.save()


        session.flash({ notification: 'Post Added!' })

        return response.redirect('/posts')
    }

    async edit({ params, view }) {
        const post = await Post.find(params.id)

        return view.render('posts.edit', {
            posts: post.toJSON()
    })

    }

    async update ({params, request, response, session}) {

        // Validate input
        const validation = await validate(request.all(), {
            particular: 'required|min:0|max:255',
            qty:        'required|min:0|max:255',
            price:      'required|min:0|max:255',
            total:      'required|min:0'

        })

        if(validation.fails()){
        session.withErrors(validation.messages()).flashAll()
        return response.redirect('back')
        }

        const post = await Post.find(params.id)
            
        post.particular     = request.input('particular')
        post.qty            = request.input('qty')
        post.price          = request.input('price')
        post.total          = request.input('total')

        await post.save()

        session.flash({ notification: 'Post Updated!' })


        return response.redirect('/posts')

    }

        async destroy({ params, session, response}) {

        const post = await Post.find(params.id)

        await post.delete()

        session.flash({ notification: 'Post Deleted!' })


        return response.redirect('/posts')

        }


        


}

module.exports = PostController
