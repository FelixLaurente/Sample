'use strict'

//Bring in model
const InvoiceHdr = use('App/Models/InvoiceHdr')

class JqueryController {
    async index ({ view }) {
        // const posts = [
        //     {title: 'Post One', body: 'This is post one'},
        //     {title: 'Post Two', body: 'This is post two'},
        //     {title: 'Post Three', body: 'This is post three'}
        // ]

        const invoiceHdr = await InvoiceHdr.all()

        return view.render('jquery.index', {
            invoice_no      :'Latest Inventory',
            customer_name   :'Latest Inventory',
            invoice_date    :'Latest Inventory',
            invoiceHdr      : invoiceHdr.toJSON() // calling the Latest inventory
        })
    }

    async add ({ view }) {
        return view.render('jquery.add');
    }
}


module.exports = JqueryController
