'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class InvoiceDtlSchema extends Schema {
  up () {
    this.create('invoice_dtls', (table) => {
      table.bigIncrements()
      table.integer('invoice_hdr_id').unsigned().notNullable().references('id').inTable('invoice_hdrs')
      table.string('particulars', 25)
      table.float('unit_price', 5)
      table.float('qty', 5)
      table.timestamps()
    })
  }

  down () {
    this.drop('invoice_dtls')
  }
}

module.exports = InvoiceDtlSchema
