'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')




class InvoiceHdrSchema extends Schema {
  up () {
    this.create('invoice_hdrs', (table) => {
      table.increments()
      table.string('invoice_no', 25).index().notNullable()
      table.string('customer_name', 50).index().notNullable()
      table.date('invoice_date')
      table.timestamps()

      
    })
    

  }


  down () {
    this.drop('invoice_hdrs')
  }
}

module.exports = InvoiceHdrSchema
