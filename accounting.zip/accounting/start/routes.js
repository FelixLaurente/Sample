'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

//** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

Route.on('/').render('home')

Route.on('/').render('welcome')

Route.get('posts','PostController.index')

Route.get('/posts/add', 'PostController.add')

Route.get('/post/edit/:id', 'PostController.edit')

Route.get('/posts/:id', 'PostController.details')

Route.get('/posts/grandTotal:id', 'PostController.details')

Route.post('/posts', 'PostController.store')

Route.put('/posts/:id', 'PostController.update')

Route.delete('/posts/:id', 'PostController.destroy')

/*************************************************************/

// Route.get('jquery','JqueryController.index')

// Route.get('/jquery/add', 'JqueryController.add')

// Route.get('/jquery/edit/:id', 'JqueryController.edit')

// //viewing of records
// Route.get('/jquery/:id', 'JqueryController.details')

// // adding of record
// Route.post('/jquery', 'JqueryController.store')

// // updating of record
// Route.patch('/jquery/:id', 'JqueryController.update')

// // deleting of record
// Route.delete('/jquery/:id', 'JqueryController.destroy')