
var myList = ['apple', 'bananas', 'orange'];