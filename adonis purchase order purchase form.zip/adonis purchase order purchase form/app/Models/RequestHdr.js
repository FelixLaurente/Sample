'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const moment = use('moment')

class RequestHdr extends Model {
    static get primaryKey() {
        return 'request_id';
    }

    getRequestDate (requestDate) {
        return moment(requestDate).format('YYYY-MM-DD')
    }

    // static get visible () {
    //     return ['purchase_id']
    //   }

    dtls() {
        return this.hasMany('App/Models/RequestDtl', 'request_id', 'request_hdr_id')
    }
}

module.exports = RequestHdr
