'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class RequestDtlSchema extends Schema {
  up () {
    this.create('request_dtls', (table) => {
      table.increments()
      table.integer('request_hdr_id').unsigned().references('request_id').inTable('request_hdrs')
      table.float('qty', 12, 5)
      table.string('particular')
      table.float('estimated_price', 12, 5)
      table.text('remarks')
      table.text('purposes')
      table.text('requested_by')
      table.text('approved_by')
      table.timestamps()
    })
  }

  down () {
    this.drop('request_dtls')
  }
}

module.exports = RequestDtlSchema
