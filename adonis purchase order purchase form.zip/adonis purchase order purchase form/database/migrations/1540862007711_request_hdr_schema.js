'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class RequestHdrSchema extends Schema {
  up () {
    this.create('request_hdrs', (table) => {
      table.increments('request_id')
      table.date('date')
      table.string('name')
      table.string('designation')
      table.string('job_no')
      table.string('job_name')
      table.string('project')
      table.timestamps()
    })
  }

  down () {
    this.drop('request_hdrs')
  }
}

module.exports = RequestHdrSchema
