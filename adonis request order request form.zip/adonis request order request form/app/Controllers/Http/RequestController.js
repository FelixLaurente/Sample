'use strict'
const RequestHdr = use('App/Models/RequestHdr')
const RequestDtl = use('App/Models/RequestDtl')

const validator = use( 'Validator' )

// remember to reference the Task model at the top
class RequestController {
    async index({ view }) {
        const rqsHdrs = await RequestHdr.all()

        return view.render('request.index', { rqsHdrs: rqsHdrs.toJSON() })
    
    }

  

    async add_form ({ view }) {
        return view.render('request.add_form')
    }

    async edit_form ({ view, params }) {
        const rqsHdr = await RequestHdr
            .query()
            .where('request_id', params.id)
            .with('dtls')
            .first();

        // return rqsHdr;
        return view.render('request.add_form', { rqsHdr : rqsHdr.toJSON() })
    }

   

    async store({ request, response, session }) {
        const dataHdr       = new RequestHdr;
      
        var data            = request.post();
        var date            = data.date;
        var name            = data.name;
        var designation     = data.designation;
        var job_no          = data.job_no;
        var job_name        = data.job_name;
        var project         = data.project;
        var qty             = data.qty;
        var particular      = data.particular;
        var estimated_price = data.estimated_price;
        var remarks         = data.remarks;
        var purposes        = data.purposes;
        // var requested_by    = data.requested_by;
        // var approved_by     = data.approved_by;  

        dataHdr.date            = date;
        dataHdr.name            = name;
        dataHdr.designation     = designation;
        dataHdr.job_no          = job_no;
        dataHdr.job_name        = job_name;
        dataHdr.project         = project
       
      

        await dataHdr.save();

        var requestID = dataHdr.request_id;

        for(var i in qty) {
            if(qty[i] == '')
                continue;

            const dataDtl     = new RequestDtl;
           
            
            dataDtl.request_hdr_id     = requestID;
            dataDtl.qty                 = qty[i];
            dataDtl.particular          = particular[i];
            dataDtl.estimated_price     = estimated_price[i];
            dataDtl.remarks	            = remarks[i];
            dataDtl.purposes	        = purposes[i];
            // dataDtl.requested_by        = requested_by[i];
            // dataDtl.approved_by         = approved_by[i];
          
        
            
            await dataDtl.save();
           
        }

        response.redirect('/')
    }

    async update({ request, response, params }) {
        var data                     = request.post();
        var qty                      = data.qty;
        var particular               = data.particular;
        var estimated_price          = data.estimated_price;
        var remarks                  = data.remarks;
        var purposes                 = data.purposes;
        // var requested_by             = data.requested_by;
        // var approved_by              = data.approved_by;

        const rqsHdr                  = await RequestHdr.find(params.id)
        rqsHdr.date                   = request.input('date')
        rqsHdr.name                   = request.input('name')
        rqsHdr.designation            = request.input('designation')
        rqsHdr.job_no                 = request.input('job_no')
        rqsHdr.job_name               = request.input('job_name')
        rqsHdr.project                = request.input('project')

        await rqsHdr.save()
        
        await RequestDtl.query().where('request_hdr_id', params.id).delete();
        
        
        for(var i in qty) {
            if(qty[i] == '')
                continue;

            const dataDtl      = new RequestDtl;
            
            
            dataDtl.request_hdr_id       = params.id;
            dataDtl.qty                   = qty[i];
            dataDtl.particular            = particular[i];
            dataDtl.estimated_price       = estimated_price[i];
            dataDtl.remarks	              = remarks[i];
            dataDtl.purposes	          = purposes[i];
            // dataDtl.requested_by          = requested_by[i];
            // dataDtl.approved_by           = approved_by[i];

            await dataDtl.save();
            
        }

        response.redirect('/')
    }

    async destroy({ params, session, response }) {
        await RequestDtl.query().where("request_hdr_id", params.id).delete();
        const rqsHdr    = await RequestHdr.find(params.id);
        await rqsHdr.delete();

        // Fash success message to session
        session.flash({ notification: 'Request deleted!' })

        return response.redirect('back')

        }
    }
        


module.exports = RequestController


