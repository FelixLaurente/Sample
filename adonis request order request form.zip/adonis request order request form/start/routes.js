'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

//Route.on('/').render('welcome')

// Get view from Browser
// Post receives from form submit
// Put receives from form submit
// Patch receives from form submit
// Delete view from Browser GET _method=delete
//Route.get('/', 'RequestController.login_form')
Route.get('/request', 'RequestController.index')
Route.get('request', 'RequestController.index')
Route.get('request/new', 'RequestController.add_form')
Route.get('request/edit/:id', 'RequestController.edit_form')
Route.get('request/:id', 'RequestController.show')
//Route.post('login','RequestController.login')
Route.post('request/new', 'RequestController.store')
Route.patch('request/edit/:id', 'RequestController.update')
Route.delete('request/:id', 'RequestController.destroy')






// Route.on('/').render('Welcome')

