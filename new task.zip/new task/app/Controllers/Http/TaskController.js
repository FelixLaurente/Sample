'use strict'

class TaskController {
}

module.exports = TaskController
