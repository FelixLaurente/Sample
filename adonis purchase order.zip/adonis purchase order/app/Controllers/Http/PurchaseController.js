'use strict'
const PurchaseHdr = use('App/Models/PurchaseHdr')
const PurchaseDtl = use('App/Models/PurchaseDtl')

const validator = use( 'Validator' )

// remember to reference the Task model at the top
class PurchaseController {
    async index({ view }) {
        const prcHdrs = await PurchaseHdr.all()
        return view.render('purchase.index', { prcHdrs: prcHdrs.toJSON() })
    }

    async add_form ({ view }) {
        return view.render('purchase.add_form')
    }

    async edit_form ({ view, params }) {
        const prcHdr = await PurchaseHdr
            .query()
            .where('purchase_id', params.id)
            .with('dtls')
            .first();

        // return prcHdr;
        return view.render('purchase.add_form', { prcHdr : prcHdr.toJSON() })
    }

   

    async store({ request, response, session }) {
        const dataHdr       = new PurchaseHdr;
        var data            = request.post();
        var purchase_no     = data.purchase_no;
        var purchase_date   = data.purchase_date;
        var supplier        = data.supplier;
        var ship_to         = data.ship_to;
        var particulars     = data.particulars;
        var unit            = data.unit;
        var unit_price      = data.unit_price;
        var qty             = data.qty;

        dataHdr.purchase_no     = purchase_no;
        dataHdr.purchase_date   = purchase_date;
        dataHdr.supplier        = supplier;
        dataHdr.ship_to         = ship_to;

        await dataHdr.save();

        var purchaseID = dataHdr.purchase_id;

        for(var i in particulars) {
            if(particulars[i] == '')
                continue;

            const dataDtl     = new PurchaseDtl;
            
            dataDtl.purchase_hdr_id = purchaseID;
            dataDtl.particular      = particulars[i];
            dataDtl.unit            = unit[i];
            dataDtl.unit_price	    = unit_price[i];
            dataDtl.quantity	    = qty[i];

            await dataDtl.save();
        }

        response.redirect('/')
    }

    async update({ request, response, params }) {
        var data            = request.post();
        var particulars     = data.particulars;
        var unit            = data.unit;
        var unit_price      = data.unit_price
        var qty             = data.qty;
        const prcHdr                = await PurchaseHdr.find(params.id)
        prcHdr.purchase_no          = request.input('purchase_no')
        prcHdr.purchase_date        = request.input('purchase_date')
        prcHdr.supplier             = request.input('supplier')
        prcHdr.ship_to              = request.input('ship_to')
        
        await prcHdr.save()
        await PurchaseDtl.query().where('purchase_hdr_id', params.id).delete();
        
        for(var i in particulars) {
            if(particulars[i] == '')
                continue;

            const dataDtl     = new PurchaseDtl;
            
            dataDtl.purchase_hdr_id = params.id;
            dataDtl.particular      = particulars[i];
            dataDtl.unit            = unit[i];
            dataDtl.unit_price	    = unit_price[i];
            dataDtl.quantity	    = qty[i];

            await dataDtl.save();
        }

        response.redirect('/')
    }

    async destroy({ params, session, response }) {
        await PurchaseDtl.query().where("purchase_hdr_id", params.id).delete();
        const prcHdr    = await PurchaseHdr.find(params.id);
        await prcHdr.delete();

        // Fash success message to session
        session.flash({ notification: 'Purchase deleted!' })

        return response.redirect('back')

        }
    }
        


module.exports = PurchaseController


