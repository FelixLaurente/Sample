'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const moment = use('moment')

class PurchaseHdr extends Model {
    static get primaryKey() {
        return 'purchase_id';
    }

    getPurchaseDate (purchaseDate) {
        return moment(purchaseDate).format('YYYY-MM-DD')
    }

    dtls() {
        return this.hasMany('App/Models/PurchaseDtl', 'purchase_id', 'purchase_hdr_id')
    }
}

module.exports = PurchaseHdr
