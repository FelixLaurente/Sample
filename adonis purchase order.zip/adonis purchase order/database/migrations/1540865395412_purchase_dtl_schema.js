'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class PurchaseDtlSchema extends Schema {
  up () {
    this.create('purchase_dtls', (table) => {
      table.increments()
      //table.integer('purchase_hdr_id').unsigned().references('purchase_id').inTable('purchase_hdrs')
      table.float('qty', 12, 5)
      table.string('particulars')
      table.float('remarks')
      table.float('purpose')
      table.timestamps()
    })
  }

  down () {
    this.drop('purchase_dtls')
  }
}

module.exports = PurchaseDtlSchema
