'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class PurchaseHdrSchema extends Schema {
  up () {
    this.create('purchase_hdrs', (table) => {
      table.date('date')
      table.string('name')
      table.string('designation')
      table.string('job_no')
      table.string('job_name')
      table.string('project_manager')
      //table.string('status').defaultTo('Open')
      table.timestamps()
    })
  }

  down () {
    this.drop('purchase_hdrs')
  }
}

module.exports = PurchaseHdrSchema
