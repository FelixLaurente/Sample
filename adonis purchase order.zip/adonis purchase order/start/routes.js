'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

//Route.on('/').render('welcome')

// Get view from Browser
// Post receives from form submit
// Put receives from form submit
// Patch receives from form submit
// Delete view from Browser GET _method=delete

Route.get('/', 'PurchaseController.index')
Route.get('purchase', 'PurchaseController.index')
Route.get('purchase/new', 'PurchaseController.add_form')
Route.get('purchase/edit/:id', 'PurchaseController.edit_form')
Route.post('purchase/new', 'PurchaseController.store')
Route.patch('purchase/edit/:id', 'PurchaseController.update')
Route.delete('purchase/:id', 'PurchaseController.destroy')

// Route.on('/').render('Welcome')

