'use strict'

class EmpWorkstationIssueController {

    async showEmpWorkstationIssue ({ view }) {     
        return view.render('workstation_issue.emp_workstation_issue')
    }
}

module.exports = EmpWorkstationIssueController
