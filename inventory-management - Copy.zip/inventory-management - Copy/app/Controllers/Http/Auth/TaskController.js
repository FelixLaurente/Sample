'use strict'
const WorkstationIssue = use('App/Models/WorkstationIssue')
const { validate } = use('Validator')

// remember to reference the Task model at the top
class TaskController {
    async emp_workstation_issue({ view }) {
        const tasks = await WorkstationIssue.all()
        return view.render('tasks.emp_workstation_issue', { tasks: tasks.toJSON() })
    }


        //const { validate } = use('Validator')
    async store({ request, response, session }) {
        
        // validate form input
        const validation = await validate(request.all(), {
            issue_id: 'required|min:3|max:255'
        })

        // show error messages upon validation fail
        if (validation.fails()) {
            session.withErrors(validation.messages())
                .flashAll()

            return response.redirect('back')
        }
        // persist to database
        const task = new WorkstationIssue()
        task.issue_id = request.input('issue_id')
        task.workstation_id = request.input('workstation_id')
        task.issue = request.input('issue')
        task.fixes = request.input('fixes')
        task.fixed_by = request.input('fixed_by')
        task.fixed_on = request.input('fixed_on')
        task.added_by = request.input('added_by')
        task.added_on = request.input('added_on')
        
        await task.save()

        // Fash success message to session
        session.flash({ notification: 'Task added!' })

        return response.redirect('back')
    }

    async destroy({ params, session, response }) {

        const task = await WorkstationIssue.find(params.id)
  await task.delete()

    // Fash success message to session
    session.flash({ notification: 'ISSUE deleted!' })

    return response.redirect('back')

    }
}

module.exports = TaskController
