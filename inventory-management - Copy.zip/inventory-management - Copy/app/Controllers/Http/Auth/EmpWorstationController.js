'use strict'

class EmpWorkstationController {
        async index ({ view }) {     
            return view.render('workstation.emp_workstation')
        }
    }


module.exports = EmpWorkstationController