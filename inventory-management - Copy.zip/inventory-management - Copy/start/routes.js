'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/


const Route = use('Route')

Route.on('/').render('home').as('home').middleware(['auth'])

Route.get('register', 'Auth/RegisterController.showRegisterForm').middleware (['authenticated'])
Route.post('register', 'Auth/RegisterController.register').as('register')
Route.get('register/confirm/:token', 'Auth/RegisterController.confirmEmail' )
Route.get('login', 'Auth/LoginController.showLoginForm').middleware(['authenticated'])
Route.post('login', 'Auth/LoginController.login').as('login')
Route.get('logout', 'Auth/AuthenticatedController.logout')
Route.get('password/reset', 'Auth/PasswordResetController.showLinkRequestForm')
Route.post('password/email', 'Auth/PasswordResetController.sendResetLinkEmail')
Route.get('password/reset/:token', 'Auth/PasswordResetController.showResetForm')
Route.post('password/reset', 'Auth/PasswordResetController.reset')
Route.get('emp_workstation','Auth/EmpWorstationController.index')
Route.get('emp_workstation_issue','Auth/EmpWorkstationIssueController.showEmpWorkstationIssue')

Route.get('/', 'TaskController.emp_workstation_issue')
Route.post('emp_workstation_issue', 'Auth/TaskController.store')
Route.delete('emp_workstation_issue/:id', 'Auth/TaskController.destroy')










// Get view from Browser
// Post receives from form submit
// Put receives from form submit
// Patch receives from form submit
// Delete view from Browser GET _method=delete

// Route.get('/', 'TaskController.index')
// Route.post('tasks', 'TaskController.store')
// Route.delete('tasks/:id', 'TaskController.destroy')

