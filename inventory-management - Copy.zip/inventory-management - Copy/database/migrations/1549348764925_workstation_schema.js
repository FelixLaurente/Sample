'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WorkstationSchema extends Schema {
  up () {
    this.create('workstations', (table) => {
      table.increments()
      table.string('workstation_id')
      table.string('workstation_name')
      table.string('workstation_status')
      table.string('workstation_user')
      table.timestamps()
    })
  }

  down () {
    this.drop('workstations')
  }
}

module.exports = WorkstationSchema
